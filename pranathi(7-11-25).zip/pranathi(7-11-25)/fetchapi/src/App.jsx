import React, { useEffect } from 'react'
import Imagefetch from './Imagefetch'

function App() {
  useEffect(()=>{
    fetch("https://jsonplaceholder.typicode.com/posts")
        .then(response=>response.json())
        .then(data=>console.log(data))
        .catch(err=>console.error(err))
  },[])
  return (
    <div>
      <div>check your console log</div>
      <Imagefetch/>
    </div>
  )
}
 
export default App