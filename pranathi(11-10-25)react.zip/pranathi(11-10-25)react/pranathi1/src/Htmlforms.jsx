import React from 'react'

function Htmlforms() {
  return (
    <div>
        <form>
            <input type="email" id="user" /><br /><br />
            <input type="password" id="user" /> <br /><br />
            <button>Submit</button>
        </form>
    </div>
  )
}

export default Htmlforms