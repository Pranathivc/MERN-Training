import  { useState,React } from 'react'

function Simplevalidation() {
    const [email,setEmail]=useState("");
    const [error,setError]=useState("");

    const handleSubmit=(e)=>{ 
        e.preventDefault();
        if(!email.includes("@")){
            setError("");
            alert("please enter valid email");
        }
        else{
            setError("");
            alert(`Email Submitted: ${email}`);
        }
        
    };
  return (
    <div>
        <form onSubmit={handleSubmit}>
            <input type="email" placeholder="enter valid email" value={email} onChange={(e)=>setEmail(e.target.value)} />
            <button type="submit">Submit</button>
           {error && <p style={{color:"red"}}>{error}</p>}
     
        </form>
    </div>
  )
}

export default Simplevalidation