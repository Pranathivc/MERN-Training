import React, { useState } from 'react'

function Twowaybinding() {
    const [message,setmessage]=useState("");

  return (
    <div>
        <input type="text" placeholder='type here' value={message} onChange={(e)=>setmessage(e.target.value)} />
        <p>You typed:{message}</p>
       
    </div>
  )
}

export default Twowaybinding