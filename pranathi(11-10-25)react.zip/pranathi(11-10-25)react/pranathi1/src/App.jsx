import React from 'react'
import Htmlforms from './Htmlforms'
import MyForm from './Forms'
import Twowaybinding from './Twowaybinding'
import Simplevalidation from './Simplevalidation'

function App() {
  return (
    <div>
      <div>App</div>
      <Htmlforms/>
      <MyForm/>
      <Twowaybinding/>
      <Simplevalidation/>
    </div>
  
  )
}

export default App