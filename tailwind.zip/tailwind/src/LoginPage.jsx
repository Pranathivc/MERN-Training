import React from 'react';

const LoginPage = () => {
  return (
    <div className="w-full max-w-md p-10 bg-white bg-opacity-90 rounded-3xl shadow-2xl backdrop-blur-md">
      <h1 className="text-4xl font-extrabold text-center text-gradient bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 mb-8">
        Welcome Back
      </h1>
      <form className="space-y-6">
        <div>
          <label htmlFor="email" className="block mb-2 text-sm font-semibold text-gray-700">
            Email Address
          </label>
          <input
            type="email"
            id="email"
            placeholder="you@example.com"
            className="w-full px-5 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-4 focus:ring-pink-300 transition"
          />
        </div>
        <div>
          <label htmlFor="password" className="block mb-2 text-sm font-semibold text-gray-700">
            Password
          </label>
          <input
            type="password"
            id="password"
            placeholder="••••••••"
            className="w-full px-5 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-4 focus:ring-pink-300 transition"
          />
        </div>
        <button
          type="submit"
          className="w-full py-3 mt-2 text-white bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 rounded-xl shadow-lg hover:scale-105 transform transition duration-300"
        >
          Sign In
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-gray-600">
        Don't have an account?{' '}
        <a href="#" className="font-semibold text-pink-600 hover:underline">
          Sign Up
        </a>
      </p>
    </div>
  );
};

export default LoginPage;
