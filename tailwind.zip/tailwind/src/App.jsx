import React from 'react'
import LoginPage from './LoginPage'

function App() {
  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <LoginPage/>
    </div>
  )
}

export default App