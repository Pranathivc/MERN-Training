import React from "react";

function Car(props){
return(
    <>
    {props.brand && <h1>My Car is a {props.brand}!</h1>}
    <h1>My Car is a {props.color}!</h1>
    </>
)
}
export default Car