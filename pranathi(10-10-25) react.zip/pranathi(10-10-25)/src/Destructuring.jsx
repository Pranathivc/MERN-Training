import React from "react";

//method 1
// function Car1({model,color}){
//     return(
//         <div>
//             <h2>My Car is {model}</h2>
//             <h2>My Car is {color}</h2>
//         </div>
//     )
// }

//method 2
// function Car1(props){
//     const {brand,model}=props;
//     return(
//             <h2>I Love my {brand} {model} </h2>

//     )
// }

//rest operator
function Car1({color,model,...rest}){
    return(
            <h2>I Love my {color} {model} {rest.brand} {rest.year} </h2>

    )
}
export default Car1