import React from "react";

//level 1
function Parent1({studentName}){
    return(
        <div style={{background:"lightblue",padding:"10px",margin:"10px"}}>
            <h2>parent component</h2>
            <Child studentName={studentName}/>
        </div>
    )
}

//level 2
function Child({studentName}){
    return(
        <div style={{background:"pink",padding:"10px",margin:"10px"}}>
            <h3>child component</h3>
            <GrandChild studentName={studentName}/>
        </div>
    )
}

//level 3
function GrandChild({studentName}){
    return(
        <div style={{background:"lightblue",padding:"10px",margin:"10px"}}>
            <h4>GrandChild component</h4>
            <GreatGrandChild studentName={studentName}/>
        </div>
    )
}

//level 4
function GreatGrandChild({studentName}){
    return(
        <div style={{background:"pink",padding:"10px",margin:"10px"}}>
            <h5>GreatGrandChild component</h5>
           <p>Hello <b>{studentName}</b>, this value was passed from the App component through 3 other component!</p>
        </div>
    )
}
export default Parent1