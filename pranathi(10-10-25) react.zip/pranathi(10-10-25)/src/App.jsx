import React from 'react'
import FirstComponent from './firstcomponent'
import Fruit from './ClassComponent'
import Argument from './Argument'
import Parent from './PropsChildren'
import ClassResult from './ConditionalRendering'
import Car from './LogicalAnd'
import ClassResult1 from './Ternary'
import Car1 from './Destructuring'
import Parent1 from './PropsDrilling'

function App() {
  return (
    <div>
      <div>App</div>
       {/* <FirstComponent/>
       <Fruit/>
       <Argument name="pranathi" phno="78"/>
       <Parent/> */}
     <ClassResult isresult={true}/>
     {/* <ClassResult isresult={false}/> */}
     <Car brand="Ford"/>
     <ClassResult1 isresult={false}/>
     <Car1 brand="Ford" model="Mustang" color="red" year={1969}/>
     <Parent1 studentName="Pranathi"/>
    </div>
  )
}
export default App