import React, { useEffect,useState } from 'react'

function UsersList() {
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);

    useEffect(()=>{
        async function fetchData(){
            const res=await fetch("https://jsonplaceholder.typicode.com/users");
            const data=await res.json();
            setUsers(data);
            setLoading(false);
        }

        fetchData();
    },[]) //fetch once
  return (
   <div>
    <h2>Users List</h2>

    {/* ternary operator */}
    {loading ? (
        <p>Loading...</p>
    ):(
        <ul>
            {users.map((users)=>(
                <li key={users.id}>{users.name}</li>
            ))}
        </ul>
    )}
   </div>
  )
}

export default UsersList