import React, { useEffect, useState } from 'react'

function Timer() {
    const [seconds,setSeconds]=useState(0);

    useEffect(()=>{
        const timer=setInterval(()=>{
            setSeconds((s)=>s+2);
        },1000);

        //cleanup function
        return()=>{
            clearInterval(timer);
            console.log("timer cleared");
        }
    },[])
 return <h2>Time:{seconds}s</h2>
}

export default Timer